陆雨甜 / Yutian Lu · 双语作品集

解压后，用 Chrome、Edge、Safari 或 Firefox 打开 Portfolio.html。无需安装软件或连接网络。支持中英切换、项目图集和投递版编辑。

After unzipping, open Portfolio.html in a browser. No installation or network connection is required.
